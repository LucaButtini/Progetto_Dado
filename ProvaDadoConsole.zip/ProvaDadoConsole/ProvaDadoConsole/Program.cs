﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvaDadoConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Gara gara = new Gara(new Giocatore("lucio"), new Giocatore("lucy"), new Dado(6), 2);
            gara.Round();
            Console.ReadLine();
            gara.Round();
            gara.Round();
            Console.ReadLine();
        }
    }
}
