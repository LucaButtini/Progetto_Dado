﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvaDadoConsole
{
    internal class Dado
    {
        Random rnd;
        int _nFaccie;
        public Dado(int nFaccie)
        {
            rnd = new Random();
            _nFaccie = nFaccie;
        }
        public int LancioDado()
        {
            return rnd.Next(1, _nFaccie + 1);
        }
        public string ScriviDado() //metodo di prova
        {
            return ($"numero: {LancioDado()}");
        }
    }
}
